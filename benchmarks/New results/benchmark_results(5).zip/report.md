# Comparative Benchmark Results

## 1. Overall Accuracy

| Method | Accuracy | Coverage | Mean Time (ms) |
|--------|----------|----------|----------------|
| cnn | 53.3% | 100.0% | 174.9 |
| a1 | 16.7% | 100.0% | 10869.4 |
| a2 | 13.3% | 100.0% | 7395.4 |
| b1 | 0.0% | 0.0% | 33727.9 |
| b2 | 0.0% | 0.0% | 33388.9 |

## 2. Accuracy by Scenario

| Scenario | N | CNN | A1 | A2 | B1 | B2 |
|----------|---|-----|----|----|----|----|
| ood | 10 | 20% | 20% | 20% | 0% | 0% |
| confusing | 10 | 60% | 30% | 20% | 0% | 0% |
| easy | 10 | 80% | 0% | 0% | 0% | 0% |

## 3. Oracle Impact: A2 vs A1

*How much raw LLM benefits from perfect vision-only trait knowledge.*

- A1 accuracy: 16.7%
- A2 accuracy: 13.3%
- Delta (A2 - A1): -3.3%

## 4. Trait Extractor Impact: B1 vs B2

*Performance lost to imperfect trait extraction. Positive extractor_penalty = B1 performs worse than B2.*

- B1 accuracy (extracted traits): 0.0%
- B2 accuracy (oracle traits): 0.0%
- Extractor penalty (B1 - B2): +0.0%

## 5. Confusing Pair Breakdown

| Pair | N | CNN | A1 | A2 | B1 | B2 |
|------|---|-----|----|----|----|----|
| AM.MU-NONE | 1 | 100% | 100% | 100% | 0% | 0% |
| AM.VI-NONE | 1 | 100% | 0% | 0% | 0% | 0% |
| BO.BA-BO.ED | 4 | 75% | 50% | 25% | 0% | 0% |
| CA.CI-HY.PS | 4 | 25% | 0% | 0% | 0% | 0% |
